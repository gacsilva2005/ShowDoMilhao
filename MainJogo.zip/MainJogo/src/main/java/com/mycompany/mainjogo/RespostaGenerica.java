/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

import java.util.List;

public class RespostaGenerica {
    private Integer idRsposta;
    private List enunciadoResposta;
    private Integer idPerguntaGenerica;

    public Integer getIdRsposta() {
        return idRsposta;
    }

    public void setIdRsposta(Integer idRsposta) {
        this.idRsposta = idRsposta;
    }
    
    public List getEnunciadoResposta() {
        return enunciadoResposta;
    }
    

    public RespostaGenerica(Integer idRsposta, List enunciadoResposta, Integer idPerguntaGenerica){
        this.idRsposta = idRsposta;
        this.enunciadoResposta = enunciadoResposta;
        this.idPerguntaGenerica = idPerguntaGenerica;
    }


    public void setEnunciadoResposta(List enunciadoResposta) {
        this.enunciadoResposta = enunciadoResposta;
    }

    public Integer getIdPerguntaGenerica() {
        return idPerguntaGenerica;
    }

    public void setIdPerguntaGenerica(Integer idPerguntaGenerica) {
        this.idPerguntaGenerica = idPerguntaGenerica;
    }

    public void conferirResposta(){
        
    }
}
