package com.mycompany.mainjogo;
public class Dica {
    private boolean dicaAtivada;

    //GET E SET
    public boolean getDicaAtivada(){
        return dicaAtivada;
    }
    public void setDicaAtivada(boolean dicaAtivada){
        this.dicaAtivada = dicaAtivada;
    }

    //MÉTODO CONSTRUTOR
    public Dica(boolean dicaAtivada){
        this.dicaAtivada = dicaAtivada;
    }

    //MÉTODO DA CLASSE
    public void eliminarAlternativa(){

    }
}
