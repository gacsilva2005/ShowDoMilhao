package com.mycompany.mainjogo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
    public boolean existe(Aluno usuario) throws Exception{
        // criar um comando SQL de consulta
        // executar esse comando no banco
        // vai receber como retorno a resposta do comando
        
        String sql = "SELECT * FROM jogador "
                + "WHERE nome_jogador = ? AND senha = ?";
        try(
           // cria a conexao com o banco e guardar no objeto conn
           Connection conn = ConexaoBD.obterConexao();
           // transforma a String sql em um comando SQL de fato
           PreparedStatement ps = conn.prepareStatement(sql)
        )
        {
           // substitui o place holder
           ps.setString(1, usuario.getNome());
           ps.setString(2, usuario.getSenha());
           
           // rs guarda a grid retornada pelo comando select
           try(ResultSet rs = ps.executeQuery()){
               return rs.next();
           }
        }
    }    
}

