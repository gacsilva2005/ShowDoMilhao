package com.mycompany.mainjogo;
public class Aluno extends AbstractPessoa implements interfaceJogador {
    private Integer serie;

    // Construtor completo
    public Aluno(String nome, String id, String email, String senha, Integer serie) {
        super(nome, id, email, senha);
        this.serie = serie;
    }

    // === Novo: construtor somente para login ===
    public Aluno(String nome, String senha) {
        super(nome, /* id */ "", /* email */ "", senha);
        this.serie = null;
    }

    // getters/setters de série abaixo...
    public Integer getSerie() { return serie; }
    public void setSerie(Integer serie) { this.serie = serie; }

    // Removei o método público `void Usuario(...)` que não fazia nada.

    // Métodos da interfaceJogador (podem ficar vazios por enquanto)
    @Override public void jogar() { }
    @Override public void consultarPontuacao() { }
    @Override public void fazerLogin() { }
    @Override public void escolherAlternativa() { }
    @Override public void solicitarDesistencia() { }
    @Override public void responderAlternativa() { }
}
