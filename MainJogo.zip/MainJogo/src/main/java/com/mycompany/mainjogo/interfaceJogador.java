package com.mycompany.mainjogo;
public interface interfaceJogador {
    void jogar();
    void consultarPontuacao();
    void fazerLogin();
    void escolherAlternativa();
    void solicitarDesistencia();
    void responderAlternativa();
}