/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

public class PerguntaGenerica {
    private String alternativaGenerica;
    private Integer idPerguntaRandom;
    private String enunciadoGenerico;
    private boolean respostaCorreta;
    private Integer pontuacao;

    public String getAlternativa() {
        return alternativaGenerica;
    }
    
    public void setAlternativaGenerica(String alternativaGenerica) {
        this.alternativaGenerica = alternativaGenerica;
    }
    
    public void setIdPerguntaRandom(Integer idPerguntaRandom) {
        this.idPerguntaRandom = idPerguntaRandom;
    }

    public Integer getIdPerguntaRandom() {
        return idPerguntaRandom;
    }

    public void setEnunciadoGenerico(String enunciadoGenerico){
        this.enunciadoGenerico = enunciadoGenerico;
    }

    public String getEnunciadoGenerico() {
        return enunciadoGenerico;
    }

    public boolean getRespostaCorreta() {
        return respostaCorreta;
    }

    public void setRespostaCorreta(boolean respostaCorreta) {
        this.respostaCorreta = respostaCorreta;
    }

    public Integer getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(Integer pontuacao) {
        this.pontuacao = pontuacao;
    }

    public PerguntaGenerica(String alternativaGenerica, String enunciadoGenerico, boolean respostaCorreta, Integer pontuacao){
        this.alternativaGenerica = alternativaGenerica;
        this.enunciadoGenerico = enunciadoGenerico;
        this.respostaCorreta = respostaCorreta;
        this.pontuacao = pontuacao;
    }
}

