package com.mycompany.mainjogo;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoBD {
    private static String host = "localhost";
    private static String porta = "3306";
    private static String db = "poligenio";
    private static String usuario = "root";
    private static String senha = "imtdb";

    public static Connection obterConexao() throws Exception{
        //criar a string de conexão
        // jdbc:mysql://localhost:3306/poligenio
        String url = "jdbc:mysql://" + host + ":" + porta + "/" + db + "?useTimezone=true&serverTimezone=UTC&useUnicode=true&characterEncoding=utf8";
        System.out.println("Banco de Dados Conectado");
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url,usuario,senha);
        
    }
    
}
