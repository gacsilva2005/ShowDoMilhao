/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

public class PerguntaCriada {
    private Integer dificuldade;
    private String alternativa;
    private String enunciado;
    private boolean respostaCorreta;
    private Integer pontuacao;
    private Materia materia;

    public Integer getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(Integer dificuldade) {
        this.dificuldade = dificuldade;
    }

    public String getAlternativa() {
        return alternativa;
    }

    public void setAlternativa(String alternativa) {
        this.alternativa = alternativa;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public boolean isRespostaCorreta() {
        return respostaCorreta;
    }

    public void setRespostaCorreta(boolean respostaCorreta) {
        this.respostaCorreta = respostaCorreta;
    }

    public Integer getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(Integer pontuacao) {
        this.pontuacao = pontuacao;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setMateria(Materia materia) {
        this.materia = materia;
    }

    public PerguntaCriada(Integer dificuldade, String alternativa, String enunciado, boolean respostaCorreta, Integer pontuacao, Materia materia) {
        this.dificuldade = dificuldade;
        this.alternativa = alternativa;
        this.enunciado = enunciado;
        this.respostaCorreta = respostaCorreta;
        this.pontuacao = pontuacao;
        this.materia = materia;
    }

    public void verificarRespostaPreenchida(){
        
    }
}

