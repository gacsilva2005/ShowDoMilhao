package com.mycompany.mainjogo;
public interface interfaceAdministrador {
    void fazerLogin();
    void cadastrarJogador();
    void criarSala();
    void solicitarRanking();
    void consultarRanking();
    void iniciarPartida();
    void gerenciarDiga();
    void gerenciarQuestao();
    void encerrarPartida();
}
