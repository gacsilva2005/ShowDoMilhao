/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

import java.util.ArrayList;
import java.util.List;

public class Partida {
    // Atributos privados
    private int capacidadeMaxima;
    private List<Aluno> jogadores;
    private String codigo;
    private boolean partidaIniciada;
    private int pontuacaoFinal;
    private int pontuacaoAtual;

    // Getters e Setters específicos da Classe
    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    public void setCapacidadeMaxima(int capacidadeMaxima) {
        this.capacidadeMaxima = capacidadeMaxima;
    }

    public List<Aluno> getJogadores() {
        return jogadores;
    }

    public void setJogadores(List<Aluno> jogadores) {
        this.jogadores = jogadores;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public boolean getPartidaIniciada() {
        return partidaIniciada;
    }

    public void setPartidaIniciada(boolean partidaIniciada) {
        this.partidaIniciada = partidaIniciada;
    }

    public int getPontuacaoFinal() {
        return pontuacaoFinal;
    }

    public void setPontuacaoFinal(int pontuacaoFinal) {
        this.pontuacaoFinal = pontuacaoFinal;
    }

    public int getPontuacaoAtual() {
        return pontuacaoAtual;
    }

    public void setPontuacaoAtual(int pontuacaoAtual) {
        this.pontuacaoAtual = pontuacaoAtual;
    }

    //MÉTODO CONSTRUTOR 
    public Partida(int capacidadeMaxima, String codigo, List<Aluno> jogadores) {
        this.capacidadeMaxima = capacidadeMaxima;
        this.codigo = codigo;
        this.pontuacaoFinal = 0;
        this.jogadores = new ArrayList<>();
        this.partidaIniciada = false;
        this.pontuacaoAtual = 0;
    }

    // Métodos públicos (sem implementação)
    public void iniciarPartida() {
        
    }

    public void encerrarPartida() {
        
    }

    public void aplicarPontuacao() {
        
    }

    public void habilitarDicas() {
        
    }

    public void iniciarPontuacao() {
        
    }

    public void verificarQuantidadeDeJogadores() {
        
    }

    public void removerJogador() {
        
    }

    public void partidaConcluida() {
       
    }

    public void proximaPergunta() {
        
    }

    public void encerrarQuestionario() {
        
    }
}
