/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

import java.util.List;

public class RespostaCriada {
    private Integer idRsposta;
    private List enunciadoRespostaCriada;
    private Integer idPerguntaCriada;

    public Integer getIdRsposta() {
        return idRsposta;
    }

    public void setIdRsposta(Integer idRsposta) {
        this.idRsposta = idRsposta;
    }
    
    public List getEnunciadoResposta() {
        return enunciadoRespostaCriada;
    }
    
    public void setEnunciadoResposta(List enunciadoResposta) {
        this.enunciadoRespostaCriada = enunciadoResposta;
    }

    public Integer getIdPerguntaGenerica() {
        return idPerguntaCriada;
    }

    public void setIdPerguntaGenerica(Integer idPerguntaGenerica) {
        this.idPerguntaCriada = idPerguntaGenerica;
    }
    
    public RespostaCriada(Integer idRsposta, List enunciadoRespostaCriada, Integer idPerguntaCriada){
        this.idRsposta = idRsposta;
        this.enunciadoRespostaCriada = enunciadoRespostaCriada;
        this.idPerguntaCriada = idPerguntaCriada;
    }

    public void conferirResposta(){
        
    }

}