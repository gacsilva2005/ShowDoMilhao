/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

public class SalaGenerica{
        // Atributo
    private tipoSala tipoSala;
    
        // Construtor
    public SalaGenerica(tipoSala tipoSala) {
        this.tipoSala = tipoSala;
    }
    
        // Getters e Setters
    public tipoSala getTipoSala() {
        return tipoSala;
    }
    
    public void setTipoSala(tipoSala tipoSala) {
        this.tipoSala = tipoSala.GENERICA;
    }
    
        // Métodos públicos (sem implementação)
    public void adicionarPerguntaGenerica() {
    
    }
    
    public void exibirAlternativaGenerica() {

    }
    
    public void embaralharAlternativas() {
        
    }
    
    public void exibirPergunta() {
        
    }
    
    public void adicionarAlternativasGenericas() {
        
    }
    
    public void sortearQuestao() {
        
    }
    
}
