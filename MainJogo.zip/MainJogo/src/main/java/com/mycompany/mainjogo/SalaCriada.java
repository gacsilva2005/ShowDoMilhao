/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

public class SalaCriada {
    // Atributo
    private tipoSala tipoSala;


    // Getter e Setter
    public tipoSala getTipoSala() {
        return tipoSala;
    }

    public void setTipoSala(tipoSala tipoSala) {
        this.tipoSala = tipoSala;
    }



    // Construtor
    public SalaCriada(tipoSala tipoSala) {
        this.tipoSala = tipoSala.CRIADA;
    }



    // Métodos públicos
    public void adicionarPergunta() {
    
    }

    public void atualizarPergunta() {

    }

    public void excluirPergunta() {

    }

    public void lerPergunta() {

    }

    public void exibirAlternativas() {

    }

    public void exibirPergunta() {

    }

    public void adicionarAlternativa() {

    }

    public void criarPergunta() {

    }

    public void criarAlternativa() {

    }
}