/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjogo;

public class Sistema {
    public void CrudBd(){

    }

    public void autenticarUsuario(){

    }
    
    public void carregarRanking(){

    }

    public void iniciarPartida(){

    }

    public void notificarCadastro(){

    }

    public void verificarUsuarioLogado(){

    }

    public void solicitarCodigo(){

    }

    public void inserirJogador(){

    }

    public void gerarRanking(){

    }

    public void armazenarPontuacao(){

    }

    public void mostrarRanking(){

    }

    public void calcularPontuacao(){

    }

    public void removerJogador(){
        
    }
}

