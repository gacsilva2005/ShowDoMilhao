package com.mycompany.mainjogo;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainJogo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tela de Login");
        frame.setSize(300, 180);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel userLabel = new JLabel("Usuário:");
        userLabel.setBounds(20, 20, 80, 25);
        frame.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(100, 20, 160, 25);
        frame.add(userText);

        JLabel passwordLabel = new JLabel("Senha:");
        passwordLabel.setBounds(20, 60, 80, 25);
        frame.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(100, 60, 160, 25);
        frame.add(passwordText);

        JButton loginButton = new JButton("Entrar");
        loginButton.setBounds(100, 100, 160, 25);
        frame.add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String login = userText.getText();
                String senha = new String(passwordText.getPassword());

                try {
                    // usa o construtor só com nome+senha
                    Aluno usuario = new Aluno(login, senha);
                    DAO dao = new DAO();
                    if (dao.existe(usuario)) {
                        JOptionPane.showMessageDialog(null, "Bem-vindo, " + usuario.getNome() + "!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Usuário ou senha inválidos.");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro técnico. Tente novamente mais tarde.");
                    ex.printStackTrace();
                }
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
