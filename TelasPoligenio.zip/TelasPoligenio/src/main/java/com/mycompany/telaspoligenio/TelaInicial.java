package com.mycompany.telaspoligenio;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.net.URL;

public class TelaInicial extends JFrame {

    private CardLayout cardLayout;
    private JPanel painelPrincipal;

    public TelaInicial() {
        setSize(1920, 1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);

        cardLayout = new CardLayout();
        painelPrincipal = new JPanel(cardLayout);

        try {
            PanelInicial telaInicioPanel = new PanelInicial();
            painelPrincipal.add(telaInicioPanel, "TelaInicial");
            add(painelPrincipal);
            cardLayout.show(painelPrincipal, "TelaInicial");

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao inicializar a tela: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaInicial tela = new TelaInicial();
            tela.setVisible(true);

        });
    }

    public static class PanelInicial extends JPanel {

        private BufferedImage imagemDeFundo;
        private BufferedImage imagemBotaoJogar;
        private BufferedImage imagemInputRA;
        private BufferedImage imageminputSenha;

        private String telaLogin = "/imagens/telaLogin.png";
        private String imagemBotaoJogarPath = "/imagens/botaoEntrarLogin.png";
        private String imagemInputRAPath = "/imagens/inputBoxRA.png";
        private String imagemInputSenhaPath = "/imagens/inputBoxSenha.png";

        public PanelInicial() throws IOException {
            setLayout(null);

            // Carrega a imagem de fundo
            URL URLlogin = getClass().getResource(telaLogin);
            if (URLlogin != null) {
                try {
                    imagemDeFundo = ImageIO.read(URLlogin);
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Erro ao carregar imagem de fundo: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                System.out.println("Imagem de fundo não encontrada.");
            }

            // Carrega a imagem do botão
            URL URLbotaoEntrar = getClass().getResource(imagemBotaoJogarPath);
            if (URLbotaoEntrar != null) {
                try {
                    imagemBotaoJogar = ImageIO.read(URLbotaoEntrar);
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Erro ao carregar imagem do botao: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                System.out.println("Imagem do botão não encontrada.");
            }

            // Carrega a imagem do input RA
            URL URLinputRA = getClass().getResource(imagemInputRAPath);
            if (URLinputRA != null) {
                try {
                    imagemInputRA = ImageIO.read(URLinputRA);
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Erro ao carregar imagem do input RA: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                System.out.println("Imagem do input RA não encontrada.");
            }

            URL URLinputSenha = getClass().getResource(imagemInputSenhaPath);
            if (URLinputSenha != null) {
                try {
                    imageminputSenha = ImageIO.read(URLinputSenha);
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Erro ao carregar imagem do input senha: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                System.out.println("Imagem do input RA não encontrada.");
            }

            // Adiciona imagem do botão como JButton customizado
            if (imagemBotaoJogar != null) {
                JButton botaoJogar = new JButton() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2d = (Graphics2D) g.create();
                        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        int largura = (int) (imagemBotaoJogar.getWidth() * 0.8);
                        int altura = (int) (imagemBotaoJogar.getHeight() * 0.8);
                        g2d.drawImage(imagemBotaoJogar, 0, 0, largura, altura, this);
                        g2d.dispose();
                    }

                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension((int) (imagemBotaoJogar.getWidth() * 0.8),
                                (int) (imagemBotaoJogar.getHeight() * 0.8));
                    }
                };
                botaoJogar.setBounds(670, 600,
                        (int) (imagemBotaoJogar.getWidth() * 0.8),
                        (int) (imagemBotaoJogar.getHeight() * 0.8));
                botaoJogar.setBorderPainted(false);
                botaoJogar.setContentAreaFilled(false);
                botaoJogar.setFocusPainted(false);
                botaoJogar.setOpaque(false);
                botaoJogar.setCursor(new Cursor(Cursor.HAND_CURSOR));
                add(botaoJogar);
            }

            // Adiciona imagem do campo RA como JLabel
            if (imagemInputRA != null) {
                JLabel campoRA = new JLabel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2d = (Graphics2D) g.create();
                        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        int largura = (int) (imagemInputRA.getWidth() * 0.8);
                        int altura = (int) (imagemInputRA.getHeight() * 0.8);
                        g2d.drawImage(imagemInputRA, 0, 0, largura, altura, this);
                        g2d.dispose();
                    }

                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension((int) (imagemInputRA.getWidth() * 0.8),
                                (int) (imagemInputRA.getHeight() * 0.8));
                    }
                };

                campoRA.setBounds(500, 355,
                        (int) (imagemInputRA.getWidth() * 0.8),
                        (int) (imagemInputRA.getHeight() * 0.8));
                campoRA.setOpaque(false);
                campoRA.setLayout(null);

                // Campo de texto sobre a imagem do RA
                JTextField campoTextoRA = new JTextField();
                campoTextoRA.setBounds(77, 27, 400, 50);
                campoTextoRA.setBorder(null);
                campoTextoRA.setOpaque(false);
                campoTextoRA.setForeground(Color.BLACK);
                campoTextoRA.setFont(new Font("Jockey One", Font.PLAIN, 28));

                campoRA.add(campoTextoRA);
                add(campoRA);
            }
            // Campo de senha (deve estar DENTRO do try)
            if (imageminputSenha != null) {
                JLabel campoSenha = new JLabel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2d = (Graphics2D) g.create();
                        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        int largura = (int) (imageminputSenha.getWidth() * 0.8);
                        int altura = (int) (imageminputSenha.getHeight() * 0.8);
                        g2d.drawImage(imageminputSenha, 0, 0, largura, altura, this);
                        g2d.dispose();
                    }

                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension((int) (imageminputSenha.getWidth() * 0.8),
                                (int) (imageminputSenha.getHeight() * 0.8));
                    }
                };

                campoSenha.setBounds(500, 475,
                        (int) (imageminputSenha.getWidth() * 0.8),
                        (int) (imageminputSenha.getHeight() * 0.8));
                campoSenha.setOpaque(false);

                // Campo de texto sobre a imagem da senha
                JTextField campoTextoSenha = new JTextField();
                campoTextoSenha.setBounds(115, 27, 400, 50);
                campoTextoSenha.setBorder(null);
                campoTextoSenha.setOpaque(false);
                campoTextoSenha.setForeground(Color.BLACK);
                campoTextoSenha.setFont(new Font("Jockey One", Font.PLAIN, 28));

                campoSenha.add(campoTextoSenha);
                add(campoSenha);
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            if (imagemDeFundo != null) {
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.drawImage(imagemDeFundo, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
