public enum TipoSala {
        CRIADA,
        GENÉRICA
}
