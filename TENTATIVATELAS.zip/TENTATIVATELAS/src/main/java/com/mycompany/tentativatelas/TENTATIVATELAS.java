package com.mycompany.tentativatelas;

//IMPORTANDO BIBLIOTECAS
import com.mycompany.tentativatelas.TELACODIGO.PainelTelaCodigo;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

//Criando uma classe para a primeira tela e extendendo o Jframe
public class TENTATIVATELAS extends JFrame {
        
        //
        private CardLayout cardLayout; //Instância para gerenciar troca de telas
        private JPanel painelPrincipal; //JPanel onde o CardLayout vai atuar
        
        //Criando um método Construtor
        public TENTATIVATELAS() {
            
            //Criando as configurações da janela do programa
            setSize(1920, 1080); //Definindo tamanho
            setExtendedState(JFrame.MAXIMIZED_BOTH); //Abrindo a janela em full screen
            setUndecorated(true); //Tirando o head e barra de tarefas da tela
            
            //Criando instâncias das Classes dentro do método construtor
            cardLayout = new CardLayout();
            painelPrincipal = new JPanel(cardLayout);

            //Painéis do JPanel
            PainelComImagem painelInicial = new PainelComImagem(this);
            PainelTelaCodigo painelCodigo = new PainelTelaCodigo(painelPrincipal);
            
            //Nomeando os painéis de acordo com o nome de cada tela
            painelPrincipal.add(painelInicial, "TENTATIVATELAS");
            painelPrincipal.add(painelCodigo, "TELACODIGO");
            
            //Criando o painel principal e habilitando sua visibilidade
            add(painelPrincipal);
            setVisible(true);
        }
        
        //Método para mostrar a tela <---------- VERIFICAR ESTA LINHA
        public void mostrarTela(String nomeTela) {
            cardLayout.show(painelPrincipal, nomeTela);
        }
        
        /*Método para garantir que a criação e exibição da tela seja feita no 
        Swing e a EDT consiga gerenciar a execução dos objetos gráficos.
        
        Event Dispatch Thread (EDT) -----É uma Thread especial que processa os 
        eventos da interface gráfica que utilizam o SWING
        */
        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> new TENTATIVATELAS());
        }

        //Painel da TELA INICIAL
        static class PainelComImagem extends JPanel {
            //Criando variáveis para receber as imagens
            private BufferedImage imagemDeFundo;
            private Image imagemBotaoJogar;
            private Image imagemBotaoConfig;
            
            //Criando Construtor para a TELA INICIAL
            public PainelComImagem(TENTATIVATELAS janela) {
                setLayout(null);
                
                try {
                    //Carregando imagens dos arquivos do notebook/computador
                    imagemDeFundo = ImageIO.read(new File("C://Users//gacsilva//Downloads//Frame 2.png"));
                    imagemBotaoJogar = ImageIO.read(new File("C://Users//gacsilva//Downloads//Group 12.png"));
                    imagemBotaoConfig = ImageIO.read(new File("C://Users//gacsilva//Downloads//Group 13.png"));
                    
                    //Criar e personalizar os botões com as imagens carregadas
                    JButton botaoJogar = new JButton() {
                        
                        //Usando método herdado da classe Graphics para renderizar as imagens carregadas
                        @Override
                        protected void paintComponent(Graphics g) {
                            Graphics2D g2d = (Graphics2D) g.create();
                            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                            int largura = (int) (imagemBotaoJogar.getWidth(null) * 0.8);
                            int altura = (int) (imagemBotaoJogar.getHeight(null) * 0.8);
                            g2d.drawImage(imagemBotaoJogar, 0, 0, largura, altura, this);
                            g2d.dispose();
                        }
                    };
                    
                    //Criando os botões, posicionando e dando suas devidas funções (Entrar na tela de jogo e configurações)
                    botaoJogar.setBounds(100, 400, (int) (imagemBotaoJogar.getWidth(null) * 0.8), (int) (imagemBotaoJogar.getHeight(null) * 0.8));
                    botaoJogar.setBorderPainted(false);
                    botaoJogar.setContentAreaFilled(false);
                    botaoJogar.setFocusPainted(false);
                    botaoJogar.setOpaque(false);
                    botaoJogar.addActionListener(e -> {
                        janela.mostrarTela("TELACODIGO"); // Troca de tela aqui
                    });

                    JButton botaoConfig = new JButton() {
                        @Override
                        protected void paintComponent(Graphics g) {
                            Graphics2D g2d = (Graphics2D) g.create();
                            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                            int largura = (int) (imagemBotaoConfig.getWidth(null) * 0.8);
                            int altura = (int) (imagemBotaoConfig.getHeight(null) * 0.8);
                            g2d.drawImage(imagemBotaoConfig, 0, 0, largura, altura, this);
                            g2d.dispose();
                        }
                    };
                    botaoConfig.setBounds(100, 540, (int) (imagemBotaoConfig.getWidth(null) * 0.8), (int) (imagemBotaoConfig.getHeight(null) * 0.8));
                    botaoConfig.setBorderPainted(false);
                    botaoConfig.setContentAreaFilled(false);
                    botaoConfig.setFocusPainted(false);
                    botaoConfig.setOpaque(false);
                    botaoConfig.addActionListener(e -> System.out.println("Botão CONFIGURAÇÕES clicado!"));
                    
                    //Adicionando os botões no JPanel
                    add(botaoJogar);
                    add(botaoConfig);
                    
                    //Mudando o cursor de acordo com a interação aos botões
                    botaoJogar.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    botaoConfig.setCursor(new Cursor(Cursor.HAND_CURSOR));
                
                    //Se algo der problema no try, o catch irá devolver o erro de forma impressa
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
            //Renderizando e adicionando a imagem de fundo do programa.
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (imagemDeFundo != null) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2d.drawImage(imagemDeFundo, 0, 0, getWidth(), getHeight(), this);
                    g2d.dispose();
                }
            }
        }
    }