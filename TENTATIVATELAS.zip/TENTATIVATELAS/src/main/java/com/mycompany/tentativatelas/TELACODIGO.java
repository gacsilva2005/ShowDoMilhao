package com.mycompany.tentativatelas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class TELACODIGO extends JFrame {
    private CardLayout cardLayout;
    private JPanel panelContainer;

    public TELACODIGO() {
        setTitle("Tela com Imagem");
        setSize(1920, 1080);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true); // remove bordas e barra de título
        
        // Configura o layout de cartões
        cardLayout = new CardLayout();
        panelContainer = new JPanel(cardLayout);
        
        // Cria as telas que serão adicionadas ao CardLayout
        PainelTelaCodigo painelTelaCodigo = new PainelTelaCodigo(panelContainer);
        TENTATIVATELAS painelOutro = new TENTATIVATELAS();
        
        // Adiciona as telas ao panelContainer
        panelContainer.add(painelTelaCodigo, "TELACODIGO");
        panelContainer.add(painelOutro, "TENTATIVATELAS");
        
        // Adiciona o panelContainer à tela principal
        add(panelContainer);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TELACODIGO());
    }

    static class PainelTelaCodigo extends JPanel {    
        private BufferedImage imagemFundo;
        private BufferedImage imagemInputBox;
        private BufferedImage imagemInputBoxNoText;
        private BufferedImage imagemEntrar;
        private BufferedImage imagemVoltar;
        private boolean clicado = false;
        private JPanel panelContainer;

        public PainelTelaCodigo(JPanel panelContainer) {
            this.panelContainer = panelContainer;
            setLayout(null); // necessário para posicionar elementos com coordenadas

            try {
                imagemFundo = ImageIO.read(new File("C://Users//gacsilva//Downloads//FundoTelaCodigo.png"));
                imagemInputBox = ImageIO.read(new File("C://Users//gacsilva//Downloads//Group 19.png"));
                imagemInputBoxNoText = ImageIO.read(new File("C://Users//gacsilva//Downloads//InserirCodigoNoText.png"));
                imagemEntrar = ImageIO.read(new File("C://Users//gacsilva//Downloads//Group 18.png"));
                imagemVoltar = ImageIO.read(new File("C://Users//gacsilva//Downloads//Group 17.png"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            JButton botaoVoltar = new JButton();
            botaoVoltar.setBounds(490, 540, (int)(imagemVoltar.getWidth(null) * 0.7),
                                            (int)(imagemVoltar.getHeight(null) * 0.7));
            botaoVoltar.setOpaque(false);
            botaoVoltar.setContentAreaFilled(false);
            botaoVoltar.setBorder(null);
            botaoVoltar.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    CardLayout cl = (CardLayout) (panelContainer.getLayout());
                    cl.show(panelContainer, "TENTATIVATELAS"); // Navega para a tela "TENTATIVATELAS"
                }
            });
            
            add(botaoVoltar);
            botaoVoltar.setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Campo de texto transparente (sobre a imagem)
            JTextField textField = new JTextField();
            textField.setBounds(400, 323, 590, 50);
            textField.setFont(new Font("Kreon", Font.PLAIN, 24));
            textField.setOpaque(false);
            textField.setForeground(Color.BLACK);
            textField.setBorder(null);
            textField.setVisible(false);
            add(textField);
            
            addMouseListener(new MouseAdapter(){
                @Override
                public void mouseClicked(MouseEvent e){
                    Point ponto = e.getPoint();
                    
                    Rectangle areaClique = new Rectangle(350, 300, 650, 125);
                    Rectangle areaVoltar = new Rectangle(490, 540, 
                            (int)(imagemVoltar.getWidth(null) * 0.7),
                            (int)(imagemVoltar.getHeight(null) * 0.7)
                    );
                    
                    if (areaVoltar.contains(ponto)) {
                        // FECHA a janela atual
                        SwingUtilities.getWindowAncestor(PainelTelaCodigo.this).dispose();

                        // ABRE a nova tela que você quer (substitua pela sua tela desejada)
                        new TENTATIVATELAS(); // coloque o nome correto aqui
                        return;
                    }
                  
                    if (areaClique.contains(e.getPoint()) && !clicado){
                        clicado = true;
                        textField.setVisible(true);
                        textField.requestFocusInWindow();
                        repaint();
                    }
                    else {
                        if (clicado){
                            clicado = false;
                            textField.setVisible(false);
                            repaint();
                        }
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (imagemFundo != null) {
                g2d.drawImage(imagemFundo, 0, 0, getWidth(), getHeight(), this);
            }
            
            int largura = (int) (imagemInputBox.getWidth(null) * 0.7);
            int altura = (int) (imagemInputBox.getHeight(null) * 0.7);
            
            if (!clicado && imagemInputBox != null) {
                g2d.drawImage(imagemInputBox, 350, 300, largura, altura, this); // alinhado com o JTextField
            }
            else if(clicado && imagemInputBoxNoText != null){
                g2d.drawImage(imagemInputBoxNoText, 350, 300, largura, altura, this);
            }
            
            if (imagemEntrar != null) {
                int larguraBotao = (int) (imagemEntrar.getWidth(null) * 0.7);
                int alturaBotao = (int) (imagemEntrar.getHeight(null) * 0.7);
                g2d.drawImage(imagemEntrar, 490, 450, larguraBotao, alturaBotao, this); // ajuste Y se necessário
            }
            
            if (imagemVoltar != null) {
                int larguraVoltar = (int) (imagemVoltar.getWidth(null) * 0.7);
                int alturaVoltar = (int) (imagemVoltar.getHeight(null) * 0.7);
                g2d.drawImage(imagemVoltar, 490, 540, larguraVoltar, alturaVoltar, this); // ajuste Y se necessário
            }

            g2d.dispose();
        }
    }
}
